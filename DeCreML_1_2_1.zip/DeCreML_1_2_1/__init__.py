# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsApplication
from .provider import DeCreMLProvider

class DeCreMLPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.action = None

    def initGui(self):
        # Registrar el provider de procesamiento
        self.provider = DeCreMLProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)
        
        # Crear acción para la barra de herramientas
        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, 'img.png')
        
        # Verificar si el archivo de ícono existe
        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
        else:
            # Usar ícono por defecto si no existe
            icon = QIcon()
        
        self.action = QAction(icon, "DeCreML 1.2.0", self.iface.mainWindow())
        self.action.triggered.connect(self.run_algorithm)
        self.action.setWhatsThis("Ejecutar DeCreML 1.2.0 - Clasificación Machine Learning")
        
        # Agregar a la barra de herramientas
        self.iface.addToolBarIcon(self.action)
        
        # Agregar al menú de complementos
        self.iface.addPluginToMenu("&DeCreML", self.action)

    def unload(self):
        # Remover de la barra de herramientas y menú
        if self.action:
            self.iface.removePluginMenu("&DeCreML", self.action)
            self.iface.removeToolBarIcon(self.action)
        
        # Remover el provider de procesamiento
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

    def run_algorithm(self):
        """Abrir directamente el diálogo del algoritmo DeCreML"""
        try:
            # Método 1: Usar el processing execAlgorithmDialog
            from processing import execAlgorithmDialog
            
            # Buscar nuestro algoritmo en el registro
            registry = QgsApplication.processingRegistry()
            algorithm = registry.algorithmById("machine_learning:DeCreML 1.2.0")
            
            if algorithm:
                # Ejecutar el diálogo del algoritmo
                execAlgorithmDialog(algorithm)
            else:
                # Método alternativo si no se encuentra por ID
                self.open_algorithm_directly()
                
        except Exception as e:
            # Si falla, intentar método directo
            try:
                self.open_algorithm_directly()
            except Exception as e2:
                # Último recurso
                self.iface.messageBar().pushWarning(
                    "DeCreML", 
                    f"No se pudo abrir el algoritmo: {str(e2)}"
                )

    def open_algorithm_directly(self):
        """Método alternativo para abrir el algoritmo"""
        try:
            # Importar y crear el algoritmo directamente
            from .decreml_algorithm import Decreml120
            from processing.gui.AlgorithmDialog import AlgorithmDialog
            
            # Crear instancia del algoritmo
            algorithm = Decreml120()
            
            # Crear el diálogo
            dlg = AlgorithmDialog(algorithm, parent=self.iface.mainWindow())
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()
            
        except Exception as e:
            # Intentar con el método estándar de processing
            try:
                from processing import execAlgorithmDialog
                from processing.modeler.ModelerUtils import AlgorithmProxy
                
                algorithm = Decreml120()
                proxy = AlgorithmProxy(algorithm)
                execAlgorithmDialog(proxy)
                
            except Exception as e2:
                raise Exception(f"Error abriendo algoritmo: {str(e)} - {str(e2)}")

def classFactory(iface):
    return DeCreMLPlugin(iface)