# -*- coding: utf-8 -*-
from qgis.core import QgsProcessingProvider
from .decreml_algorithm import Decreml120

class DeCreMLProvider(QgsProcessingProvider):
    def __init__(self):
        super().__init__()
    
    def loadAlgorithms(self):
        self.addAlgorithm(Decreml120())
    
    def id(self):
        return 'machine_learning'
    
    def name(self):
        return 'Machine Learning'
    
    def longName(self):
        return 'Machine Learning - DeCreML 1.2.0'