# -*- coding: utf-8 -*-
"""
DeCreML – Complemento QGIS
Autor: Equipo DeCreML
Versión 2025 Mejorada
"""

from qgis.PyQt.QtCore import QObject
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from qgis.core import QgsApplication
from qgis import processing
from qgis.utils import iface

# ✅ Importa el provider
from .processing.provider import DeCreMLProvider


class DeCreMLPlugin(QObject):

    def __init__(self, iface):
        QObject.__init__(self)
        self.iface = iface
        self.provider = None
        self.action = None

    # -------------------------------------------------------------
    # ✅ INICIO DEL PLUGIN
    # -------------------------------------------------------------
    def initGui(self):

        # Registrar provider
        self.provider = DeCreMLProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)
        print("✅ DeCreML: Provider registrado correctamente.")

        # Crear acción con icono
        icon_path = self.pluginIcon()
        self.action = QAction(QIcon(icon_path), "Abrir DeCreML", self.iface.mainWindow())
        self.action.triggered.connect(self.openAlgorithmDialog)

        # Añadir icono al toolbar y menú
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&DeCreML", self.action)

    # -------------------------------------------------------------
    # ✅ ABRIR EL ALGORITMO EN EL DIÁLOGO ORIGINAL DE QGIS
    # -------------------------------------------------------------
    def openAlgorithmDialog(self):
        try:
            # Debe coincidir con id:algoritmo
            processing.execAlgorithmDialog("DeCreML:decreml120")
        except Exception as e:
            self.iface.messageBar().pushWarning(
                "DeCreML",
                f"No se pudo abrir el algoritmo: {e}"
            )

    # -------------------------------------------------------------
    # ✅ DESCARGAR EL PLUGIN
    # -------------------------------------------------------------
    def unload(self):

        try:
            self.iface.removePluginMenu("&DeCreML", self.action)
        except:
            pass

        try:
            self.iface.removeToolBarIcon(self.action)
        except:
            pass

        try:
            QgsApplication.processingRegistry().removeProvider(self.provider)
        except:
            pass

    # -------------------------------------------------------------
    # ✅ RUTA DEL ICONO
    # -------------------------------------------------------------
    def pluginIcon(self):
        import os
        return os.path.join(os.path.dirname(__file__), "icon.png")
