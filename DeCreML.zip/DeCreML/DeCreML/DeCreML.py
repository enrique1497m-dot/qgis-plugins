
from qgis.core import QgsProcessingProvider
from .processing.provider import DeCreMLProvider

class DeCreMLPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        self.provider = DeCreMLProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        QgsApplication.processingRegistry().removeProvider(self.provider)
