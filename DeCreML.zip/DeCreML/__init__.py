
def classFactory(iface):
    from .DeCreML import DeCreMLPlugin
    return DeCreMLPlugin(iface)
